import React, { useContext } from "react";
import Book from "./Book";
import { BookContext } from "./App";

export default function BookList({ books }) {

  const { handleBookAdd } = useContext(BookContext);

  return (
    <div className="book-list">      
        {books.map((book,index) => {
          return <Book key={book.id} book={book} index={index}/>;
        })}      
      <div className="book-list__add-book-btn-container">
        <button className="btn btn--primary" onClick={handleBookAdd}>
          Add New Book
        </button>        
      </div>  
      
    </div>
  );
}
