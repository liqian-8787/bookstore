import React, { useState, useEffect } from "react";
import BookList from "./BookList";
import "../css/app.css";
import { v4 as uuidv4 } from "uuid";
import AddModal from "./AddModal";

export const BookContext = React.createContext();
const LOCAL_STORAGE_KEY = "bookWithReact";
const LOCAL_STORAGE_KEY_MODAL = "bookModalSave";

function App() {
  /* hooks */
  const [selectedBookId, setSelectedBookId] = useState();
  const [books, setBooks] = useState(sampleBooks);
  const [modalSave, setModalSave] = useState(uuidv4()); 
  const [modalShow, setModalShow] = useState(false);
  const [newBookAdded, setNewBookAdded] = useState(false);

  const selectedBook = books.find((book) => book.id === selectedBookId);

  const handleModalClose = () => {
    //when the current modal comes from the add new book button
    //remove the current selected book from the list
    //reset the status of newBookAdded hook to fase after        
    if(newBookAdded)
      storeBooks(books.filter((book) => book.id !== selectedBookId))      
    setNewBookAdded(false);
    setModalShow(false)   
  };

  const handleModalShow = (id) => {
    handleBookSelect(id);
    setModalShow(true);
  };

  const handleModalSave = (id) => {
    //once modal is saved, the newBookAdded will be set to false
    setModalSave(uuidv4());
    storeBooks(books)
    setNewBookAdded(false);
    setModalShow(false);
  };

  useEffect(() => {
    const bookJSON = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (bookJSON != null) setBooks(JSON.parse(bookJSON));
    if (modalSave != null)
      setModalSave(localStorage.getItem(LOCAL_STORAGE_KEY_MODAL));
  }, []);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(books));
    localStorage.setItem(LOCAL_STORAGE_KEY_MODAL, modalSave);
  }, [modalSave]);
 
  const BookContextValue = {
    handleBookAdd,
    handleBookDelete,
    handleBookChange,
    handleBookSelect,
    handleModalShow,
    handleModalClose,
    handleModalSave,
    modalShow,
  };

  function storeBooks(books){
    setBooks(books);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(books));    
  }

  function handleBookSelect(id) {
    setSelectedBookId(id);
  }

  function handleBookAdd() {         
    setNewBookAdded(true);
    setSelectedBookId(newBook.id);   
    setBooks([...books, newBook]);   
    setModalShow(true);
  }
  
  function handleBookDelete(id) {
    if (selectedBookId != null && selectedBookId === id) {
      setSelectedBookId(undefined);
    }
    storeBooks(books.filter((book) => book.id !== id));      
  }

  function handleBookChange(id, book) {
    const newBooks = [...books];
    const index = newBooks.findIndex((b) => b.id === id);
    newBooks[index] = book;
    setBooks(newBooks);
  }

  return (
    <BookContext.Provider value={BookContextValue}>
      <BookList books={books} />     
      {selectedBookId && <AddModal {...selectedBook} />}
    </BookContext.Provider>
  );
}

/*new book model to add*/
const newBook = {
  id: uuidv4(),
  name: "",
  price: "",
  category: "",
  description: "",
}; 
/*Static list of books*/
const sampleBooks = [
  {
    id: 1,
    name: "I LOVE YOU TO THE MOON AND BACK",
    price: "10.99",
    category: "kids fiction",
    description:
      "A joyful celebration of the love between a parent and the special little person in his or her life!",
  },
  {
    id: 2,
    name: "THE ITSY BITSY BUNNY",
    price: "7.99",
    category: "kids fiction",
    description:
      'The itsy bitsy bunny is ready for an Easter adventure as he tries to deliver the best Easter ever. Little ones will love this bouncy twist on the classic nursery rhyme "The Itsy Bitsy Spider"!',
  },
  {
    id: 3,
    name: "THE ANTIQUARIAN STICKER BOOK",
    price: "33.99",
    category: "Crafts & Hobbies Books",
    description:
      "Peel and decorate or browse and feast on the beauty of this lush sticker book, unlike any other. This treasure trove of authentic historical prints from around the ornate Victorian era can be used to embellish stationery and wrapping, create an exquisite collage, or adorn your coffee table or decorative shelf. ",
  },
];
export default App;
