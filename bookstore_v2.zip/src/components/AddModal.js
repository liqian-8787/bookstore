import React, {useContext} from "react";
import { Modal, Button } from 'react-bootstrap';
import { BookContext } from "./App";
import  BookEdit from './BookEdit'
export default function AddModal(book) {
  const {handleModalClose,modalShow,handleModalSave} = useContext(BookContext) 
  return (
    <>   
      <Modal
        show={modalShow}
        onHide={handleModalClose}
        backdrop="static"
        keyboard={false}
        size="lg"
      >
        <Modal.Header closeButton>
          <Modal.Title>Book Detail</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <BookEdit book={book}/>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={()=>{handleModalSave()}}>Save</Button>
          <Button variant="secondary" onClick={handleModalClose}>
            Cancel
          </Button>        
        </Modal.Footer>
      </Modal>      
    </>
  );
}
