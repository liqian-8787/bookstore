import React, { useContext } from 'react'
import { BookContext } from "./App";

export default function Book(props) {
    
    const { handleBookDelete, handleModalShow } = useContext(BookContext)    
    return (
        <div className="book">
            <div className="book__header">                
                <h4 
                    className="book__title" 
                    onClick={()=>handleModalShow(props.book.id)}>
                    {props.index+1}. {props.book.name}
                </h4>
                <div>                   
                    <button className="btn btn--danger" 
                            onClick={()=>handleBookDelete(props.book.id)}>
                            Delete
                    </button>
                </div>
            </div>
            <div className="book__row"> 
                <span className="book__label">Price: $</span>
                <span className="book__value">{props.book.price}</span>
            </div>
            <div className="book__row">
                <span className="book__label">Category:</span>
                <span className="book__value">{props.book.category}</span>
            </div>           
        </div>
    )
}
