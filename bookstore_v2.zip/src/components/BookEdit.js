import React, {useContext} from "react";
import { BookContext} from './App'

export default function BookEdit({book}) {

    const {handleBookChange} = useContext(BookContext)

    function handleChange(changes){
      handleBookChange(book.id, {...book, ...changes}) /*deconstruction*/
    }


  return (
    <div className="book-edit">      
      <div className="book-edit__details-grid">
        <label htmlFor="name" className="book-edit__label">
          Name
        </label>
        <input
          type="text"
          name="name"
          id="name"
          value={book.name}
          onChange={e => handleChange({name: e.target.value})}
          className="book-edit__input"
        />
        <label 
            htmlFor="price" 
            className="book-edit__label">
           Price
        </label>
        <div className="book-edit__price-wrap">          
            <span className="book-edit__dollor-placeholder">$</span> 
            <input 
              type="number" 
              name="price" 
              id="price"            
              value={book.price}
              onChange={e => {handleChange({price: e.target.value})}}
              className="book-edit__input book-edit__input-price" />          
        </div>
        
        <label 
            htmlFor="category" 
            className="book-edit__label">
           Category
        </label>
        <input 
            type="text" 
            name="category" 
            id="category"
            value={book.category}
            onChange={e => handleChange({category: e.target.value})}
            className="book-edit__input" />
        <label 
            htmlFor="instructions"
            className="book-edit__label">
            Description
        </label>
        <textarea 
            name="description" 
            className="book-edit__input"
            value={book.description}
            onChange={e => handleChange({description: e.target.value})}
            id="description" />            
      </div>
    </div>   
  );
}
